<?php hide($form['field_answer_question']);?>
<?php hide($form['additional_settings']);?>
<?php print drupal_render_children($form); ?>
